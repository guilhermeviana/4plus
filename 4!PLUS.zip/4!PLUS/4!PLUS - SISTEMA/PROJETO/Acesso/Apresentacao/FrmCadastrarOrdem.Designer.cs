﻿namespace Apresentacao
{
    partial class FrmCadastrarOrdem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCadastrarOrdem));
            this.labelNumOrdem = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNumOrdem = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.comboBoxCliente = new System.Windows.Forms.ComboBox();
            this.cLIENTEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oFICINADataSet1 = new Apresentacao.OFICINADataSet1();
            this.vEICULOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oFICINADataSet4 = new Apresentacao.OFICINADataSet4();
            this.textBoxIdCliente = new System.Windows.Forms.TextBox();
            this.textBoxCpf = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxIdVeiculo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxModelo = new System.Windows.Forms.TextBox();
            this.textBoxAno = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxIdMecanica = new System.Windows.Forms.TextBox();
            this.comboBoxDefeito = new System.Windows.Forms.ComboBox();
            this.dEFEITOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oFICINADataSet3 = new Apresentacao.OFICINADataSet3();
            this.textBoxIdDefeito = new System.Windows.Forms.TextBox();
            this.textBoxDescricaoDefeito = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonCalcular = new System.Windows.Forms.Button();
            this.textBoxValorTotal = new System.Windows.Forms.TextBox();
            this.textBoxValorOficina = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxValorMecanica = new System.Windows.Forms.TextBox();
            this.textBoxValorDefeito = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxMarca = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxMecanica = new System.Windows.Forms.ComboBox();
            this.mECANICABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oFICINADataSet2 = new Apresentacao.OFICINADataSet2();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.buttonSalvar = new System.Windows.Forms.Button();
            this.buttonCancelar = new System.Windows.Forms.Button();
            this.cLIENTETableAdapter = new Apresentacao.OFICINADataSet1TableAdapters.CLIENTETableAdapter();
            this.mECANICATableAdapter = new Apresentacao.OFICINADataSet2TableAdapters.MECANICATableAdapter();
            this.dEFEITOTableAdapter = new Apresentacao.OFICINADataSet3TableAdapters.DEFEITOTableAdapter();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBoxData = new System.Windows.Forms.TextBox();
            this.comboBoxPlaca = new System.Windows.Forms.ComboBox();
            this.vEICULOBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.oFICINADataSet5 = new Apresentacao.OFICINADataSet5();
            this.vEICULOTableAdapter = new Apresentacao.OFICINADataSet4TableAdapters.VEICULOTableAdapter();
            this.vEICULOTableAdapter1 = new Apresentacao.OFICINADataSet5TableAdapters.VEICULOTableAdapter();
            this.textBoxCadastro = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_Cpf = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vEICULOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEFEITOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet3)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mECANICABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vEICULOBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet5)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelNumOrdem
            // 
            this.labelNumOrdem.AutoSize = true;
            this.labelNumOrdem.BackColor = System.Drawing.Color.Transparent;
            this.labelNumOrdem.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumOrdem.Location = new System.Drawing.Point(27, 27);
            this.labelNumOrdem.Name = "labelNumOrdem";
            this.labelNumOrdem.Size = new System.Drawing.Size(69, 18);
            this.labelNumOrdem.TabIndex = 3;
            this.labelNumOrdem.Text = "N° Ordem";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(132, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Data";
            // 
            // textBoxNumOrdem
            // 
            this.textBoxNumOrdem.BackColor = System.Drawing.Color.Silver;
            this.textBoxNumOrdem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNumOrdem.Enabled = false;
            this.textBoxNumOrdem.Location = new System.Drawing.Point(30, 43);
            this.textBoxNumOrdem.Name = "textBoxNumOrdem";
            this.textBoxNumOrdem.Size = new System.Drawing.Size(78, 20);
            this.textBoxNumOrdem.TabIndex = 4;
            this.textBoxNumOrdem.TextChanged += new System.EventHandler(this.textBoxNumOrdem_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(271, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "*Status";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Items.AddRange(new object[] {
            "EM ANÁLISE",
            "EM MANUTENÇÃO",
            "FINALIZADO"});
            this.comboBoxStatus.Location = new System.Drawing.Point(273, 42);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(177, 21);
            this.comboBoxStatus.TabIndex = 1;
            // 
            // comboBoxCliente
            // 
            this.comboBoxCliente.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxCliente.DataSource = this.cLIENTEBindingSource;
            this.comboBoxCliente.DisplayMember = "NOME";
            this.comboBoxCliente.FormattingEnabled = true;
            this.comboBoxCliente.Location = new System.Drawing.Point(104, 48);
            this.comboBoxCliente.Name = "comboBoxCliente";
            this.comboBoxCliente.Size = new System.Drawing.Size(220, 21);
            this.comboBoxCliente.TabIndex = 1;
            this.comboBoxCliente.ValueMember = "NOME";
            this.comboBoxCliente.SelectedIndexChanged += new System.EventHandler(this.comboBoxCliente_SelectedIndexChanged);
            // 
            // cLIENTEBindingSource
            // 
            this.cLIENTEBindingSource.DataMember = "CLIENTE";
            this.cLIENTEBindingSource.DataSource = this.oFICINADataSet1;
            // 
            // oFICINADataSet1
            // 
            this.oFICINADataSet1.DataSetName = "OFICINADataSet1";
            this.oFICINADataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vEICULOBindingSource
            // 
            this.vEICULOBindingSource.DataMember = "VEICULO";
            this.vEICULOBindingSource.DataSource = this.oFICINADataSet4;
            // 
            // oFICINADataSet4
            // 
            this.oFICINADataSet4.DataSetName = "OFICINADataSet4";
            this.oFICINADataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBoxIdCliente
            // 
            this.textBoxIdCliente.BackColor = System.Drawing.Color.Silver;
            this.textBoxIdCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIdCliente.Enabled = false;
            this.textBoxIdCliente.Location = new System.Drawing.Point(16, 49);
            this.textBoxIdCliente.Name = "textBoxIdCliente";
            this.textBoxIdCliente.ReadOnly = true;
            this.textBoxIdCliente.Size = new System.Drawing.Size(71, 20);
            this.textBoxIdCliente.TabIndex = 3;
            this.textBoxIdCliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCpf
            // 
            this.textBoxCpf.Location = new System.Drawing.Point(426, 298);
            this.textBoxCpf.Name = "textBoxCpf";
            this.textBoxCpf.ReadOnly = true;
            this.textBoxCpf.Size = new System.Drawing.Size(197, 20);
            this.textBoxCpf.TabIndex = 0;
            this.textBoxCpf.TextChanged += new System.EventHandler(this.textBoxCpf_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "Código";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(101, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 18);
            this.label5.TabIndex = 0;
            this.label5.Text = "*Cliente/Condutor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(423, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "CPF";
            // 
            // textBoxIdVeiculo
            // 
            this.textBoxIdVeiculo.BackColor = System.Drawing.Color.Silver;
            this.textBoxIdVeiculo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIdVeiculo.Enabled = false;
            this.textBoxIdVeiculo.Location = new System.Drawing.Point(14, 41);
            this.textBoxIdVeiculo.Name = "textBoxIdVeiculo";
            this.textBoxIdVeiculo.Size = new System.Drawing.Size(71, 20);
            this.textBoxIdVeiculo.TabIndex = 3;
            this.textBoxIdVeiculo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Código";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(102, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 18);
            this.label8.TabIndex = 0;
            this.label8.Text = "Placa";
            // 
            // textBoxModelo
            // 
            this.textBoxModelo.BackColor = System.Drawing.Color.Silver;
            this.textBoxModelo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxModelo.Enabled = false;
            this.textBoxModelo.Location = new System.Drawing.Point(371, 41);
            this.textBoxModelo.Name = "textBoxModelo";
            this.textBoxModelo.Size = new System.Drawing.Size(135, 20);
            this.textBoxModelo.TabIndex = 7;
            this.textBoxModelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxAno
            // 
            this.textBoxAno.BackColor = System.Drawing.Color.Silver;
            this.textBoxAno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAno.Enabled = false;
            this.textBoxAno.Location = new System.Drawing.Point(525, 41);
            this.textBoxAno.Name = "textBoxAno";
            this.textBoxAno.Size = new System.Drawing.Size(71, 20);
            this.textBoxAno.TabIndex = 9;
            this.textBoxAno.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(215, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 18);
            this.label9.TabIndex = 4;
            this.label9.Text = "Marca";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(371, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 18);
            this.label10.TabIndex = 6;
            this.label10.Text = "Modelo";
            // 
            // textBoxIdMecanica
            // 
            this.textBoxIdMecanica.BackColor = System.Drawing.Color.Silver;
            this.textBoxIdMecanica.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIdMecanica.Enabled = false;
            this.textBoxIdMecanica.Location = new System.Drawing.Point(35, 296);
            this.textBoxIdMecanica.Name = "textBoxIdMecanica";
            this.textBoxIdMecanica.Size = new System.Drawing.Size(71, 20);
            this.textBoxIdMecanica.TabIndex = 11;
            this.textBoxIdMecanica.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxDefeito
            // 
            this.comboBoxDefeito.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxDefeito.DataSource = this.dEFEITOBindingSource;
            this.comboBoxDefeito.DisplayMember = "NOME_DEFEITO";
            this.comboBoxDefeito.FormattingEnabled = true;
            this.comboBoxDefeito.Location = new System.Drawing.Point(104, 89);
            this.comboBoxDefeito.Name = "comboBoxDefeito";
            this.comboBoxDefeito.Size = new System.Drawing.Size(183, 21);
            this.comboBoxDefeito.TabIndex = 2;
            this.comboBoxDefeito.ValueMember = "NOME_DEFEITO";
            this.comboBoxDefeito.SelectedIndexChanged += new System.EventHandler(this.comboBoxDefeito_SelectedIndexChanged);
            // 
            // dEFEITOBindingSource
            // 
            this.dEFEITOBindingSource.DataMember = "DEFEITO";
            this.dEFEITOBindingSource.DataSource = this.oFICINADataSet3;
            // 
            // oFICINADataSet3
            // 
            this.oFICINADataSet3.DataSetName = "OFICINADataSet3";
            this.oFICINADataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBoxIdDefeito
            // 
            this.textBoxIdDefeito.BackColor = System.Drawing.Color.Silver;
            this.textBoxIdDefeito.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxIdDefeito.Enabled = false;
            this.textBoxIdDefeito.Location = new System.Drawing.Point(14, 90);
            this.textBoxIdDefeito.Name = "textBoxIdDefeito";
            this.textBoxIdDefeito.ReadOnly = true;
            this.textBoxIdDefeito.Size = new System.Drawing.Size(71, 20);
            this.textBoxIdDefeito.TabIndex = 5;
            this.textBoxIdDefeito.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDescricaoDefeito
            // 
            this.textBoxDescricaoDefeito.BackColor = System.Drawing.Color.Silver;
            this.textBoxDescricaoDefeito.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDescricaoDefeito.Enabled = false;
            this.textBoxDescricaoDefeito.Location = new System.Drawing.Point(9, 138);
            this.textBoxDescricaoDefeito.Multiline = true;
            this.textBoxDescricaoDefeito.Name = "textBoxDescricaoDefeito";
            this.textBoxDescricaoDefeito.Size = new System.Drawing.Size(279, 118);
            this.textBoxDescricaoDefeito.TabIndex = 7;
            this.textBoxDescricaoDefeito.TextChanged += new System.EventHandler(this.textBoxDescricaoDefeito_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.buttonCalcular);
            this.groupBox1.Controls.Add(this.textBoxValorTotal);
            this.groupBox1.Controls.Add(this.textBoxValorOficina);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.textBoxValorMecanica);
            this.groupBox1.Controls.Add(this.textBoxValorDefeito);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Location = new System.Drawing.Point(330, 248);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(293, 182);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Valores";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // buttonCalcular
            // 
            this.buttonCalcular.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCalcular.BackgroundImage")));
            this.buttonCalcular.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCalcular.Location = new System.Drawing.Point(155, 80);
            this.buttonCalcular.Name = "buttonCalcular";
            this.buttonCalcular.Size = new System.Drawing.Size(122, 30);
            this.buttonCalcular.TabIndex = 4;
            this.buttonCalcular.UseVisualStyleBackColor = true;
            this.buttonCalcular.Click += new System.EventHandler(this.buttonCalcular_Click);
            // 
            // textBoxValorTotal
            // 
            this.textBoxValorTotal.BackColor = System.Drawing.Color.Silver;
            this.textBoxValorTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxValorTotal.Enabled = false;
            this.textBoxValorTotal.Location = new System.Drawing.Point(11, 138);
            this.textBoxValorTotal.Multiline = true;
            this.textBoxValorTotal.Name = "textBoxValorTotal";
            this.textBoxValorTotal.Size = new System.Drawing.Size(266, 32);
            this.textBoxValorTotal.TabIndex = 8;
            this.textBoxValorTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxValorTotal.TextChanged += new System.EventHandler(this.textBoxValorTotal_TextChanged);
            // 
            // textBoxValorOficina
            // 
            this.textBoxValorOficina.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxValorOficina.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxValorOficina.Location = new System.Drawing.Point(11, 90);
            this.textBoxValorOficina.Name = "textBoxValorOficina";
            this.textBoxValorOficina.Size = new System.Drawing.Size(135, 20);
            this.textBoxValorOficina.TabIndex = 3;
            this.textBoxValorOficina.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxValorOficina.TextChanged += new System.EventHandler(this.textBoxValorOficina_TextChanged);
            this.textBoxValorOficina.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxValorOficina_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(8, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(138, 18);
            this.label18.TabIndex = 2;
            this.label18.Text = "*Taxa  Concessionária";
            // 
            // textBoxValorMecanica
            // 
            this.textBoxValorMecanica.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxValorMecanica.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxValorMecanica.Location = new System.Drawing.Point(152, 47);
            this.textBoxValorMecanica.Name = "textBoxValorMecanica";
            this.textBoxValorMecanica.Size = new System.Drawing.Size(125, 20);
            this.textBoxValorMecanica.TabIndex = 1;
            this.textBoxValorMecanica.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxValorMecanica.TextChanged += new System.EventHandler(this.textBoxValorMecanica_TextChanged);
            this.textBoxValorMecanica.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxValorMecanica_KeyPress);
            // 
            // textBoxValorDefeito
            // 
            this.textBoxValorDefeito.BackColor = System.Drawing.Color.Silver;
            this.textBoxValorDefeito.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxValorDefeito.Enabled = false;
            this.textBoxValorDefeito.Location = new System.Drawing.Point(11, 47);
            this.textBoxValorDefeito.Name = "textBoxValorDefeito";
            this.textBoxValorDefeito.Size = new System.Drawing.Size(135, 20);
            this.textBoxValorDefeito.TabIndex = 6;
            this.textBoxValorDefeito.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 31);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 18);
            this.label16.TabIndex = 5;
            this.label16.Text = "Valor Defeito";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(149, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 18);
            this.label17.TabIndex = 0;
            this.label17.Text = "*Valor Manutenção";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 122);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 18);
            this.label19.TabIndex = 7;
            this.label19.Text = "*Total";
            // 
            // textBoxMarca
            // 
            this.textBoxMarca.BackColor = System.Drawing.Color.Silver;
            this.textBoxMarca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMarca.Enabled = false;
            this.textBoxMarca.Location = new System.Drawing.Point(218, 41);
            this.textBoxMarca.Name = "textBoxMarca";
            this.textBoxMarca.Size = new System.Drawing.Size(135, 20);
            this.textBoxMarca.TabIndex = 5;
            this.textBoxMarca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(522, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 18);
            this.label11.TabIndex = 8;
            this.label11.Text = "Ano";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(11, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 18);
            this.label12.TabIndex = 3;
            this.label12.Text = "Código";
            // 
            // comboBoxMecanica
            // 
            this.comboBoxMecanica.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxMecanica.DataSource = this.mECANICABindingSource;
            this.comboBoxMecanica.DisplayMember = "NOME_MECANICA";
            this.comboBoxMecanica.FormattingEnabled = true;
            this.comboBoxMecanica.Location = new System.Drawing.Point(126, 295);
            this.comboBoxMecanica.Name = "comboBoxMecanica";
            this.comboBoxMecanica.Size = new System.Drawing.Size(183, 21);
            this.comboBoxMecanica.TabIndex = 2;
            this.comboBoxMecanica.ValueMember = "NOME_MECANICA";
            this.comboBoxMecanica.SelectedIndexChanged += new System.EventHandler(this.comboBoxMecanica_SelectedIndexChanged);
            // 
            // mECANICABindingSource
            // 
            this.mECANICABindingSource.DataMember = "MECANICA";
            this.mECANICABindingSource.DataSource = this.oFICINADataSet2;
            // 
            // oFICINADataSet2
            // 
            this.oFICINADataSet2.DataSetName = "OFICINADataSet2";
            this.oFICINADataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(102, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 18);
            this.label13.TabIndex = 0;
            this.label13.Text = "*Nome / Razão Social";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(11, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 18);
            this.label14.TabIndex = 4;
            this.label14.Text = "Código";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(102, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 18);
            this.label15.TabIndex = 1;
            this.label15.Text = "*Defeito";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(11, 122);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 18);
            this.label20.TabIndex = 6;
            this.label20.Text = "Descrição Defeito";
            // 
            // buttonSalvar
            // 
            this.buttonSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSalvar.BackgroundImage")));
            this.buttonSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSalvar.Location = new System.Drawing.Point(444, 198);
            this.buttonSalvar.Name = "buttonSalvar";
            this.buttonSalvar.Size = new System.Drawing.Size(62, 57);
            this.buttonSalvar.TabIndex = 8;
            this.buttonSalvar.UseVisualStyleBackColor = true;
            this.buttonSalvar.Click += new System.EventHandler(this.buttonSalvar_Click);
            // 
            // buttonCancelar
            // 
            this.buttonCancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCancelar.BackgroundImage")));
            this.buttonCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancelar.Location = new System.Drawing.Point(524, 198);
            this.buttonCancelar.Name = "buttonCancelar";
            this.buttonCancelar.Size = new System.Drawing.Size(62, 57);
            this.buttonCancelar.TabIndex = 9;
            this.buttonCancelar.UseVisualStyleBackColor = true;
            this.buttonCancelar.Click += new System.EventHandler(this.buttonCancelar_Click);
            // 
            // cLIENTETableAdapter
            // 
            this.cLIENTETableAdapter.ClearBeforeFill = true;
            // 
            // mECANICATableAdapter
            // 
            this.mECANICATableAdapter.ClearBeforeFill = true;
            // 
            // dEFEITOTableAdapter
            // 
            this.dEFEITOTableAdapter.ClearBeforeFill = true;
            // 
            // textBoxData
            // 
            this.textBoxData.BackColor = System.Drawing.Color.Silver;
            this.textBoxData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxData.Enabled = false;
            this.textBoxData.Location = new System.Drawing.Point(135, 43);
            this.textBoxData.Name = "textBoxData";
            this.textBoxData.ReadOnly = true;
            this.textBoxData.Size = new System.Drawing.Size(113, 20);
            this.textBoxData.TabIndex = 6;
            // 
            // comboBoxPlaca
            // 
            this.comboBoxPlaca.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxPlaca.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.vEICULOBindingSource1, "NOME_CLIENTE", true));
            this.comboBoxPlaca.FormattingEnabled = true;
            this.comboBoxPlaca.Location = new System.Drawing.Point(105, 41);
            this.comboBoxPlaca.Name = "comboBoxPlaca";
            this.comboBoxPlaca.Size = new System.Drawing.Size(87, 21);
            this.comboBoxPlaca.TabIndex = 1;
            this.comboBoxPlaca.SelectedIndexChanged += new System.EventHandler(this.comboBoxPlaca_SelectedIndexChanged);
            // 
            // vEICULOBindingSource1
            // 
            this.vEICULOBindingSource1.DataMember = "VEICULO";
            this.vEICULOBindingSource1.DataSource = this.oFICINADataSet5;
            // 
            // oFICINADataSet5
            // 
            this.oFICINADataSet5.DataSetName = "OFICINADataSet5";
            this.oFICINADataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vEICULOTableAdapter
            // 
            this.vEICULOTableAdapter.ClearBeforeFill = true;
            // 
            // vEICULOTableAdapter1
            // 
            this.vEICULOTableAdapter1.ClearBeforeFill = true;
            // 
            // textBoxCadastro
            // 
            this.textBoxCadastro.BackColor = System.Drawing.Color.Silver;
            this.textBoxCadastro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCadastro.Enabled = false;
            this.textBoxCadastro.Location = new System.Drawing.Point(475, 43);
            this.textBoxCadastro.Name = "textBoxCadastro";
            this.textBoxCadastro.Size = new System.Drawing.Size(148, 20);
            this.textBoxCadastro.TabIndex = 8;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(472, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(102, 18);
            this.label21.TabIndex = 7;
            this.label21.Text = "Cadastrado por";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.textBox_Cpf);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.textBoxIdCliente);
            this.groupBox2.Controls.Add(this.comboBoxCliente);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(21, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(602, 155);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informações Cliente";
            // 
            // textBox_Cpf
            // 
            this.textBox_Cpf.BackColor = System.Drawing.Color.Silver;
            this.textBox_Cpf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_Cpf.Enabled = false;
            this.textBox_Cpf.Location = new System.Drawing.Point(358, 48);
            this.textBox_Cpf.Name = "textBox_Cpf";
            this.textBox_Cpf.Size = new System.Drawing.Size(148, 20);
            this.textBox_Cpf.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxIdVeiculo);
            this.groupBox3.Controls.Add(this.comboBoxPlaca);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.textBoxMarca);
            this.groupBox3.Controls.Add(this.textBoxModelo);
            this.groupBox3.Controls.Add(this.textBoxAno);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(0, 85);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(602, 92);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Infomações Veículo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(355, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "CPF";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.textBoxDescricaoDefeito);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.buttonCancelar);
            this.groupBox4.Controls.Add(this.buttonSalvar);
            this.groupBox4.Controls.Add(this.comboBoxDefeito);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.textBoxIdDefeito);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Location = new System.Drawing.Point(21, 248);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(602, 267);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Outras Informações";
            // 
            // FrmCadastrarOrdem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(657, 538);
            this.ControlBox = false;
            this.Controls.Add(this.textBoxCadastro);
            this.Controls.Add(this.textBoxData);
            this.Controls.Add(this.comboBoxMecanica);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxIdMecanica);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxCpf);
            this.Controls.Add(this.comboBoxStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNumOrdem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelNumOrdem);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label21);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCadastrarOrdem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Ordem de Serviço";
            this.Load += new System.EventHandler(this.FrmCadastrarOrdem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vEICULOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEFEITOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mECANICABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vEICULOBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oFICINADataSet5)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelNumOrdem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNumOrdem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.ComboBox comboBoxCliente;
        private System.Windows.Forms.TextBox textBoxIdCliente;
        private System.Windows.Forms.TextBox textBoxCpf;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxIdVeiculo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxModelo;
        private System.Windows.Forms.TextBox textBoxAno;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxIdMecanica;
        private System.Windows.Forms.ComboBox comboBoxDefeito;
        private System.Windows.Forms.TextBox textBoxIdDefeito;
        private System.Windows.Forms.TextBox textBoxDescricaoDefeito;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxValorTotal;
        private System.Windows.Forms.TextBox textBoxValorOficina;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxValorMecanica;
        private System.Windows.Forms.TextBox textBoxValorDefeito;
        private System.Windows.Forms.TextBox textBoxMarca;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxMecanica;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button buttonSalvar;
        private System.Windows.Forms.Button buttonCancelar;
        private OFICINADataSet1 oFICINADataSet1;
        private System.Windows.Forms.BindingSource cLIENTEBindingSource;
        private OFICINADataSet1TableAdapters.CLIENTETableAdapter cLIENTETableAdapter;
        private OFICINADataSet2 oFICINADataSet2;
        private System.Windows.Forms.BindingSource mECANICABindingSource;
        private OFICINADataSet2TableAdapters.MECANICATableAdapter mECANICATableAdapter;
        private OFICINADataSet3 oFICINADataSet3;
        private System.Windows.Forms.BindingSource dEFEITOBindingSource;
        private OFICINADataSet3TableAdapters.DEFEITOTableAdapter dEFEITOTableAdapter;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBoxData;
        private System.Windows.Forms.ComboBox comboBoxPlaca;
        private OFICINADataSet4 oFICINADataSet4;
        private System.Windows.Forms.BindingSource vEICULOBindingSource;
        private OFICINADataSet4TableAdapters.VEICULOTableAdapter vEICULOTableAdapter;
        private OFICINADataSet5 oFICINADataSet5;
        private System.Windows.Forms.BindingSource vEICULOBindingSource1;
        private OFICINADataSet5TableAdapters.VEICULOTableAdapter vEICULOTableAdapter1;
        private System.Windows.Forms.Button buttonCalcular;
        private System.Windows.Forms.TextBox textBoxCadastro;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox_Cpf;
        private System.Windows.Forms.Label label1;
    }
}