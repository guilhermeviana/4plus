﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apresentacao
{
    public enum AcaoNaTela
    {
        Inserir = 0,
        Alterar = 1,
        Consultar = 2,
        //Excluir = 3,
    }
}
