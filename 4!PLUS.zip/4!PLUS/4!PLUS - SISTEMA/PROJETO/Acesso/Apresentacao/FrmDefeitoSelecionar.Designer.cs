﻿namespace Apresentacao
{
    partial class FrmDefeitoSelecionar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDefeitoSelecionar));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.buttonPesquisarDefeito = new System.Windows.Forms.Button();
            this.buttonAdicionarDefeito = new System.Windows.Forms.Button();
            this.buttonEditarDefeito = new System.Windows.Forms.Button();
            this.buttonConsultarDefeito = new System.Windows.Forms.Button();
            this.buttonExcluirDefeito = new System.Windows.Forms.Button();
            this.buttonCancelarDefeito = new System.Windows.Forms.Button();
            this.dataGridDefeito = new System.Windows.Forms.DataGridView();
            this.ColCodDefeito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColNomeDefeito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDescricaoDefeito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColValorDefeito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxPesquisarDefeito = new System.Windows.Forms.TextBox();
            this.radioButtonIdDefeito = new System.Windows.Forms.RadioButton();
            this.radioButtonNomeDefeito = new System.Windows.Forms.RadioButton();
            this.buttonAtualizar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDefeito)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonPesquisarDefeito
            // 
            this.buttonPesquisarDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonPesquisarDefeito.BackgroundImage")));
            this.buttonPesquisarDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPesquisarDefeito.Location = new System.Drawing.Point(673, 27);
            this.buttonPesquisarDefeito.Name = "buttonPesquisarDefeito";
            this.buttonPesquisarDefeito.Size = new System.Drawing.Size(35, 26);
            this.buttonPesquisarDefeito.TabIndex = 2;
            this.buttonPesquisarDefeito.UseVisualStyleBackColor = true;
            this.buttonPesquisarDefeito.Click += new System.EventHandler(this.buttonPesquisarDefeito_Click);
            // 
            // buttonAdicionarDefeito
            // 
            this.buttonAdicionarDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonAdicionarDefeito.BackgroundImage")));
            this.buttonAdicionarDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAdicionarDefeito.Location = new System.Drawing.Point(23, 407);
            this.buttonAdicionarDefeito.Name = "buttonAdicionarDefeito";
            this.buttonAdicionarDefeito.Size = new System.Drawing.Size(120, 29);
            this.buttonAdicionarDefeito.TabIndex = 5;
            this.buttonAdicionarDefeito.UseVisualStyleBackColor = true;
            this.buttonAdicionarDefeito.Click += new System.EventHandler(this.buttonAdicionarDefeito_Click);
            // 
            // buttonEditarDefeito
            // 
            this.buttonEditarDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonEditarDefeito.BackgroundImage")));
            this.buttonEditarDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonEditarDefeito.Location = new System.Drawing.Point(275, 407);
            this.buttonEditarDefeito.Name = "buttonEditarDefeito";
            this.buttonEditarDefeito.Size = new System.Drawing.Size(120, 29);
            this.buttonEditarDefeito.TabIndex = 7;
            this.buttonEditarDefeito.UseVisualStyleBackColor = true;
            this.buttonEditarDefeito.Click += new System.EventHandler(this.buttonEditarDefeito_Click);
            // 
            // buttonConsultarDefeito
            // 
            this.buttonConsultarDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonConsultarDefeito.BackgroundImage")));
            this.buttonConsultarDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonConsultarDefeito.Location = new System.Drawing.Point(149, 407);
            this.buttonConsultarDefeito.Name = "buttonConsultarDefeito";
            this.buttonConsultarDefeito.Size = new System.Drawing.Size(120, 29);
            this.buttonConsultarDefeito.TabIndex = 6;
            this.buttonConsultarDefeito.UseVisualStyleBackColor = true;
            this.buttonConsultarDefeito.Click += new System.EventHandler(this.buttonConsultarDefeito_Click);
            // 
            // buttonExcluirDefeito
            // 
            this.buttonExcluirDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExcluirDefeito.BackgroundImage")));
            this.buttonExcluirDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonExcluirDefeito.Location = new System.Drawing.Point(401, 407);
            this.buttonExcluirDefeito.Name = "buttonExcluirDefeito";
            this.buttonExcluirDefeito.Size = new System.Drawing.Size(120, 29);
            this.buttonExcluirDefeito.TabIndex = 8;
            this.buttonExcluirDefeito.UseVisualStyleBackColor = true;
            this.buttonExcluirDefeito.Click += new System.EventHandler(this.buttonExcluirDefeito_Click);
            // 
            // buttonCancelarDefeito
            // 
            this.buttonCancelarDefeito.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCancelarDefeito.BackgroundImage")));
            this.buttonCancelarDefeito.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCancelarDefeito.Location = new System.Drawing.Point(643, 407);
            this.buttonCancelarDefeito.Name = "buttonCancelarDefeito";
            this.buttonCancelarDefeito.Size = new System.Drawing.Size(120, 29);
            this.buttonCancelarDefeito.TabIndex = 9;
            this.buttonCancelarDefeito.UseVisualStyleBackColor = true;
            this.buttonCancelarDefeito.Click += new System.EventHandler(this.buttonCancelarDefeito_Click);
            // 
            // dataGridDefeito
            // 
            this.dataGridDefeito.AllowUserToAddRows = false;
            this.dataGridDefeito.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridDefeito.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridDefeito.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridDefeito.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridDefeito.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColCodDefeito,
            this.ColNomeDefeito,
            this.ColDescricaoDefeito,
            this.ColValorDefeito});
            this.dataGridDefeito.Location = new System.Drawing.Point(23, 75);
            this.dataGridDefeito.MultiSelect = false;
            this.dataGridDefeito.Name = "dataGridDefeito";
            this.dataGridDefeito.ReadOnly = true;
            this.dataGridDefeito.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridDefeito.Size = new System.Drawing.Size(740, 300);
            this.dataGridDefeito.TabIndex = 4;
            // 
            // ColCodDefeito
            // 
            this.ColCodDefeito.DataPropertyName = "ID_DEFEITO";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Navy;
            this.ColCodDefeito.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColCodDefeito.HeaderText = "ID";
            this.ColCodDefeito.Name = "ColCodDefeito";
            this.ColCodDefeito.ReadOnly = true;
            this.ColCodDefeito.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColNomeDefeito
            // 
            this.ColNomeDefeito.DataPropertyName = "NOME_DEFEITO";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColNomeDefeito.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColNomeDefeito.HeaderText = "Defeito";
            this.ColNomeDefeito.Name = "ColNomeDefeito";
            this.ColNomeDefeito.ReadOnly = true;
            this.ColNomeDefeito.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColNomeDefeito.Width = 200;
            // 
            // ColDescricaoDefeito
            // 
            this.ColDescricaoDefeito.DataPropertyName = "DESCRIÇÃO";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColDescricaoDefeito.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColDescricaoDefeito.HeaderText = "Descrição";
            this.ColDescricaoDefeito.Name = "ColDescricaoDefeito";
            this.ColDescricaoDefeito.ReadOnly = true;
            this.ColDescricaoDefeito.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColDescricaoDefeito.Width = 260;
            // 
            // ColValorDefeito
            // 
            this.ColValorDefeito.DataPropertyName = "VALOR";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColValorDefeito.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColValorDefeito.HeaderText = "Preço";
            this.ColValorDefeito.Name = "ColValorDefeito";
            this.ColValorDefeito.ReadOnly = true;
            this.ColValorDefeito.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColValorDefeito.Width = 140;
            // 
            // textBoxPesquisarDefeito
            // 
            this.textBoxPesquisarDefeito.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPesquisarDefeito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPesquisarDefeito.Location = new System.Drawing.Point(204, 27);
            this.textBoxPesquisarDefeito.Multiline = true;
            this.textBoxPesquisarDefeito.Name = "textBoxPesquisarDefeito";
            this.textBoxPesquisarDefeito.Size = new System.Drawing.Size(472, 26);
            this.textBoxPesquisarDefeito.TabIndex = 1;
            this.textBoxPesquisarDefeito.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPesquisarDefeito_KeyPress);
            // 
            // radioButtonIdDefeito
            // 
            this.radioButtonIdDefeito.AutoSize = true;
            this.radioButtonIdDefeito.Checked = true;
            this.radioButtonIdDefeito.Location = new System.Drawing.Point(22, 19);
            this.radioButtonIdDefeito.Name = "radioButtonIdDefeito";
            this.radioButtonIdDefeito.Size = new System.Drawing.Size(36, 17);
            this.radioButtonIdDefeito.TabIndex = 0;
            this.radioButtonIdDefeito.TabStop = true;
            this.radioButtonIdDefeito.Text = "ID";
            this.radioButtonIdDefeito.UseVisualStyleBackColor = true;
            this.radioButtonIdDefeito.CheckedChanged += new System.EventHandler(this.radioButtonIdDefeito_CheckedChanged);
            this.radioButtonIdDefeito.Click += new System.EventHandler(this.radioButtonIdDefeito_Click);
            // 
            // radioButtonNomeDefeito
            // 
            this.radioButtonNomeDefeito.AutoSize = true;
            this.radioButtonNomeDefeito.Location = new System.Drawing.Point(84, 19);
            this.radioButtonNomeDefeito.Name = "radioButtonNomeDefeito";
            this.radioButtonNomeDefeito.Size = new System.Drawing.Size(53, 17);
            this.radioButtonNomeDefeito.TabIndex = 1;
            this.radioButtonNomeDefeito.TabStop = true;
            this.radioButtonNomeDefeito.Text = "Nome";
            this.radioButtonNomeDefeito.UseVisualStyleBackColor = true;
            this.radioButtonNomeDefeito.CheckedChanged += new System.EventHandler(this.radioButtonNomeDefeito_CheckedChanged);
            this.radioButtonNomeDefeito.Click += new System.EventHandler(this.radioButtonNomeDefeito_Click);
            // 
            // buttonAtualizar
            // 
            this.buttonAtualizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonAtualizar.BackgroundImage")));
            this.buttonAtualizar.Enabled = false;
            this.buttonAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAtualizar.Location = new System.Drawing.Point(728, 27);
            this.buttonAtualizar.Name = "buttonAtualizar";
            this.buttonAtualizar.Size = new System.Drawing.Size(35, 26);
            this.buttonAtualizar.TabIndex = 3;
            this.buttonAtualizar.UseVisualStyleBackColor = true;
            this.buttonAtualizar.Click += new System.EventHandler(this.buttonAtualizar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.radioButtonNomeDefeito);
            this.groupBox1.Controls.Add(this.radioButtonIdDefeito);
            this.groupBox1.Location = new System.Drawing.Point(23, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(153, 47);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo de Pesquisa";
            // 
            // FrmDefeitoSelecionar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(784, 462);
            this.ControlBox = false;
            this.Controls.Add(this.buttonAtualizar);
            this.Controls.Add(this.textBoxPesquisarDefeito);
            this.Controls.Add(this.dataGridDefeito);
            this.Controls.Add(this.buttonCancelarDefeito);
            this.Controls.Add(this.buttonExcluirDefeito);
            this.Controls.Add(this.buttonConsultarDefeito);
            this.Controls.Add(this.buttonEditarDefeito);
            this.Controls.Add(this.buttonAdicionarDefeito);
            this.Controls.Add(this.buttonPesquisarDefeito);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmDefeitoSelecionar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "4! Plus - Defeito";
            this.Load += new System.EventHandler(this.FrmDefeitoSelecionar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDefeito)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonPesquisarDefeito;
        private System.Windows.Forms.Button buttonAdicionarDefeito;
        private System.Windows.Forms.Button buttonEditarDefeito;
        private System.Windows.Forms.Button buttonConsultarDefeito;
        private System.Windows.Forms.Button buttonExcluirDefeito;
        private System.Windows.Forms.Button buttonCancelarDefeito;
        private System.Windows.Forms.DataGridView dataGridDefeito;
        private System.Windows.Forms.TextBox textBoxPesquisarDefeito;
        private System.Windows.Forms.RadioButton radioButtonIdDefeito;
        private System.Windows.Forms.RadioButton radioButtonNomeDefeito;
        private System.Windows.Forms.Button buttonAtualizar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCodDefeito;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColNomeDefeito;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDescricaoDefeito;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColValorDefeito;
    }
}