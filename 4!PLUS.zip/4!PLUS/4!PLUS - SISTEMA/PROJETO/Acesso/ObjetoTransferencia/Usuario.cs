﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetoTransferencia
{
    public class Usuario
    {
        public int ID_USUARIO { get; set; }
        public string USUARIO { get; set; }
        public string SENHA { get; set; }
        public string NIVEL_ACESSO { get; set; }
    }
}
