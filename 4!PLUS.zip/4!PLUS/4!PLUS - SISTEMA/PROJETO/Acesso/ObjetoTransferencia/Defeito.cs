﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetoTransferencia
{
    public class Defeito
    {
        public int ID_DEFEITO { get; set; }
        public string NOME_DEFEITO { get; set; }
        public string DESCRIÇÃO { get; set; }
        public string VALOR { get; set; }

    }
}
